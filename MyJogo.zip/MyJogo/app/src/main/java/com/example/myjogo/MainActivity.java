package com.example.myjogo;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    private Button jogodavelha;
    private Button quebracabeca;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        jogodavelha = findViewById(R.id.jogodavelha);
        quebracabeca = findViewById(R.id.quebracabeca);

        jogodavelha.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent janela = new Intent(MainActivity.this, jogodavelha.class);
                janela.putExtra("dados", jogodavelha.getText().toString());
                startActivity(janela);


            }
        });

        quebracabeca.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent janela = new Intent(MainActivity.this, jogodavelha.class);
                janela.putExtra("dados", quebracabeca.getText().toString());
                startActivity(janela);


            }
        });

    }
}