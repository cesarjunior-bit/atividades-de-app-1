package com.example.myexfixacao;

import androidx.fragment.app.FragmentActivity;

import android.os.Bundle;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

public class MapsActivity extends FragmentActivity implements OnMapReadyCallback {

    private GoogleMap mMap;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps);
        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
    }

    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     * -30.04124601448917, -51.16640059405315
     */
    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        //posicionamento por latitude e longitude
        LatLng poa = new LatLng(-29.806817079850003, -51.1735255313127);

        //estilização do bookmark do Google Maps
        mMap.addMarker(new MarkerOptions()
                        .position(poa)
                        .title("Porto Alegre, minha casa")
                        .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_ORANGE))
                /*
                Para inserir uma imagem - logotipo no lugar do marker
                .icon(BitmapDescriptorFactory.fromResource(R.drawable.nomedaimagem))
                 */
        );

        //definir tipo de mapa que será exibido
        mMap.setMapType(GoogleMap.MAP_TYPE_HYBRID);


        //esta parte se refere à camera e zoom
        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(poa, 10));
    }
}