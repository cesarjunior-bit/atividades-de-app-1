package com.example.myexfixacao;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

class MeusLinks extends AppCompatActivity {
    private Button btnFace, btnInsta;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_links);

        btnFace = findViewById(R.id.btnFace);
        btnInsta = findViewById(R.id.btnInsta);

        btnInsta.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                abrirInsta();
            }
        });

        btnFace.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                abrirFace();
            }
        });

    }

    public void abrirInsta() {
        Intent instagram = new Intent(Intent.ACTION_VIEW, Uri.parse("http://www.instagram.com"));
        startActivity(instagram);
    }

    public void abrirFace(){
        Intent facebook = new Intent(Intent.ACTION_VIEW, Uri.parse("http://www.facebook.com.br"));
        startActivity(facebook);
    }
}