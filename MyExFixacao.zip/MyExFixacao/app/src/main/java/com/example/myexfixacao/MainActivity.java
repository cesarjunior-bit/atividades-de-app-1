package com.example.myexfixacao;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    Button btnLinks, btnMaps, btnSensorAcelerar, btnSensorLuminosidade, btnSensorProximidade;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btnLinks = findViewById(R.id.btnLinks);
        btnMaps = findViewById(R.id.btnMaps);
        btnSensorAcelerar = findViewById(R.id.btnSensorAcelerar);
        btnSensorLuminosidade = findViewById(R.id.SensorLuminosidade);
        btnSensorProximidade = findViewById(R.id.SensorProximidade);

        btnLinks.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });

        btnMaps.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });

        btnSensorAcelerar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });

        btnSensorLuminosidade.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });

        btnSensorProximidade.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });
    }
}