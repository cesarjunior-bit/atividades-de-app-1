package com.example.afreira;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.VideoView;

public class Teaser extends AppCompatActivity {
    private VideoView olhar;
    private Button btnVoltart;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_teaser);

        btnVoltart = findViewById(R.id.btnVoltart);
        olhar = findViewById(R.id.olhar);

        //declaração do caminho do vídeo, sempre da mesma maneira
        Uri caminho = Uri.parse("android.resource://" + getPackageName() + "/" + R.raw.teaser);
        olhar.setVideoURI(caminho);
        olhar.start();

        btnVoltart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                abrirVotar();
            }
        });
    }

    public void abrirVotar() {
        Intent janela = new Intent(this, MainActivity.class);
        startActivity(janela);
    }
}